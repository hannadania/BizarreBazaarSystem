import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public class BizarreBazaarGUI extends JFrame implements ActionListener {

    private Map<String, Double> myItemsList = new HashMap<>();
    private Map<String, Integer> myItemsQuantity = new HashMap<>();
    private List<JCheckBox> checkboxes = new ArrayList<>();
    private JButton nextButton;
    private JButton royaltyCardButton;

    public BizarreBazaarGUI() {
    initializeGUI();
    }

    ////////// GUI 

    private void initializeGUI() {

    JPanel mainPanel = new JPanel(new BorderLayout());
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

    JPanel itemsPanel = new JPanel(new GridLayout(0, 1));
    itemsPanel.setBackground(new Color(250, 232, 235));

    JPanel headerPanel = createHeaderPanel(mainPanel, "Welcome To Bizarre Bazaar! Choose Your Items", "flower.jpeg");
 
    mainPanel.add(headerPanel);
    mainPanel.add(itemsPanel);


        createCategoryLabel(itemsPanel, "Meat:");
        createItemCheckbox(itemsPanel, "Chicken", 8.99, 20);
        createItemCheckbox(itemsPanel, "Beef", 12.99, 15);

        createCategoryLabel(itemsPanel, "Vegetables:");
        createItemCheckbox(itemsPanel, "Broccoli", 2.49, 30);
        createItemCheckbox(itemsPanel, "Potato", 1.25, 30);

        createCategoryLabel(itemsPanel, "Fruits:");
        createItemCheckbox(itemsPanel, "Apple", 0.99, 50);
        createItemCheckbox(itemsPanel, "Orange", 0.79, 40);

        createCategoryLabel(itemsPanel, "Canned Food:");
        createItemCheckbox(itemsPanel, "Canned Tuna", 3.99, 10);
        createItemCheckbox(itemsPanel, "Canned Sardines", 5, 20);

        createCategoryLabel(itemsPanel, "Drinks");
        createItemCheckbox(itemsPanel, "Sprite", 1.99, 25);
        createItemCheckbox(itemsPanel, "Coke", 1.99, 25);

        royaltyCardButton = new JButton("Apply Royalty Card Discount");
        JPanel royaltyCardButtonPanel = new JPanel(new FlowLayout());
        royaltyCardButtonPanel.add(royaltyCardButton);

        nextButton = new JButton("Next");
        JPanel nextButtonPanel = new JPanel(new FlowLayout());
        nextButtonPanel.add(nextButton);

        mainPanel.add(royaltyCardButtonPanel);
        mainPanel.add(nextButtonPanel);

        setTitle("Bizarre Bazaar");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 700);
        setLayout(null);
        setContentPane(mainPanel);
        setLocationRelativeTo(null);
        setVisible(true);

    }




    public JPanel createHeaderPanel(JPanel mainPanel, String headerText, String photoString) {

    JPanel headerPanel = new JPanel(new BorderLayout()) {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            ImageIcon imageIcon = new ImageIcon(photoString); // Replace "flower.jpg" with your actual image file path
            Image image = imageIcon.getImage();
            g.drawImage(image, 0, 0, 600, 600, this);
        }
    };

    JLabel headerLabel = new JLabel(headerText);
    headerLabel.setFont(headerLabel.getFont().deriveFont(Font.BOLD, 24));
    headerLabel.setHorizontalAlignment(JLabel.CENTER);

    headerPanel.add(headerLabel, BorderLayout.CENTER);
    return headerPanel;
}




    private void createItemCheckbox(Container container, String itemName, double price, int stock) {
        Item item = new Item(itemName, price, stock);
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(255, 192, 203));
        JCheckBox itemCheckbox = new JCheckBox(item.getName() + " (RM" + item.getPrice() + ")");
        itemCheckbox.setFont(itemCheckbox.getFont().deriveFont(Font.BOLD, 19));
        checkboxes.add(itemCheckbox);

        JComboBox<Integer> quantityComboBox = new JComboBox<>();
        int availableStock = item.getStock();
        for (int i = 1; i <= availableStock; i++) {
            quantityComboBox.addItem(i);
        }

        itemCheckbox.addActionListener(e -> {
            if (itemCheckbox.isSelected()) {
                int selectedQuantity = (Integer) quantityComboBox.getSelectedItem();
                myItemsList.put(item.getName(), item.getPrice() * selectedQuantity);
            } else {
                myItemsList.remove(item.getName());
                myItemsQuantity.remove(item.getName());
            }
        });

        quantityComboBox.addActionListener(e -> {
            int selectedQuantity = (Integer) quantityComboBox.getSelectedItem();
            myItemsQuantity.put(item.getName(), selectedQuantity);

            if (itemCheckbox.isSelected()) {
                myItemsList.put(item.getName(), item.getPrice() * selectedQuantity);
                myItemsQuantity.put(item.getName(), selectedQuantity);
            }
        });

        panel.add(itemCheckbox, BorderLayout.WEST);
        panel.add(quantityComboBox, BorderLayout.EAST);
        container.add(panel);
    }




    private void createCategoryLabel(Container container, String categoryName) {
        JLabel categoryLabel = new JLabel(categoryName);
        categoryLabel.setFont(categoryLabel.getFont().deriveFont(Font.BOLD, 25));
        container.add(categoryLabel);
    }


    

    public double getItemsListSum() {
        double totalPrice = 0;
        for (double price : myItemsList.values()) {
            totalPrice += price;
        }
        return totalPrice;
    }

    public Map<String, Double> getMyItemsList() {
        return myItemsList;
    }

    public Map<String, Integer> getMyQuantityList() {
        return myItemsQuantity;
    }

    public JButton getNextButton() {
        return nextButton;
    }

    public JButton getRoyaltyCardButton() {
        return royaltyCardButton;
    }

    public void deselectCheckboxes() {
        for (JCheckBox checkbox : checkboxes) {
            checkbox.setSelected(false);
        }
    }

    public void clearItemData() {
        myItemsList.clear();
        myItemsQuantity.clear();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    }


}

