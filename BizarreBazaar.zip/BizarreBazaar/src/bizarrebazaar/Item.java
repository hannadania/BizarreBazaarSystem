
public class Item {

    private String name;
    private double price;
    private int stock;
    private int quantity;

    public Item(String name, double price, int stock) {
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    public String getName() {
        return name;
    }


    public double getPrice() {
        return price;
    }


    public int getStock() {
        return stock;
    }


    public int getQuantity() {
        return quantity;
    }

    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    
}

