import javax.swing.*;
import java.awt.*;

public class RoyaltyCardGUI extends JFrame {

    private JTextField royaltyCardTextField;
    private JPasswordField passwordField;
    private JButton submitButton;
    private JButton backButton;
    private BizarreBazaarGUI bizarreBazaar;


    public RoyaltyCardGUI(BizarreBazaarGUI bizarreBazaar) {

        this.bizarreBazaar = bizarreBazaar;
        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel headerPanel = bizarreBazaar.createHeaderPanel(mainPanel, "Please Enter Your Details: ", "flower.jpeg");
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        headerPanel.setPreferredSize(new Dimension(400, 100));

        JPanel detailsPanel = new JPanel(new GridLayout(0, 1));
        detailsPanel.setBackground(new Color(250, 232, 235));

        JLabel cardLabel = new JLabel("Royalty Card Number:");
        cardLabel.setFont(cardLabel.getFont().deriveFont(Font.BOLD, 19));
        detailsPanel.add(cardLabel);

        royaltyCardTextField = new JTextField(10);
        detailsPanel.add(royaltyCardTextField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(passwordLabel.getFont().deriveFont(Font.BOLD, 19));
        detailsPanel.add(passwordLabel);

        passwordField = new JPasswordField(10);
        detailsPanel.add(passwordField);

        submitButton = new JButton("Submit");
        detailsPanel.add(submitButton);

        backButton = new JButton("Back");
        detailsPanel.add(backButton);


        submitButton.addActionListener(e -> {
            submitDetails();;
        });

        backButton.addActionListener(e -> {
            bizarreBazaar.setVisible(true);
            this.dispose();
        });


        mainPanel.add(detailsPanel);

        setTitle("Royalty Card");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 700);
        setLayout(new BorderLayout());
        setContentPane(mainPanel);
        setLocationRelativeTo(null);
        setVisible(true);
    }



    private void submitDetails() {

    String royaltyCardNumber = royaltyCardTextField.getText();
    String password = new String(passwordField.getPassword());

    RoyaltyCard royaltyCard = new RoyaltyCard(royaltyCardNumber, password);
    boolean isValid = royaltyCard.validate();

    if (isValid) {
        PaymentGUI payment = new PaymentGUI(bizarreBazaar.getItemsListSum(), bizarreBazaar.getMyItemsList(),
        bizarreBazaar.getMyQuantityList(), true, bizarreBazaar);
        payment.setVisible(true);
        dispose();
    } else {
        JOptionPane.showMessageDialog(this, "Invalid Royalty Card Number or Password");
    }
}



}
