import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PaymentController {
    
    private Map<String, Double> myItemsList;

    public PaymentController(Map<String, Double> itemsList, Map<String, Integer> itemsQuantity, Boolean royalCardBoolean) {
    }


    public double calculatedDiscountedTotal(double totalAmount, double discount) {
        double discountAmount = totalAmount * discount;
        double payableAmount = totalAmount - discountAmount;
        return payableAmount;
    }


        public double calculatedDiscountedAmount(double totalAmount, double discount) {
        double discountAmount = totalAmount * discount;
        return discountAmount;
    }
    


    public boolean isBundledDiscountApplicable() {
    List<List<String>> bundles = new ArrayList<>();
    //e.g bundles.add(Arrays.asList("Chicken", "Coke"));
    //e.g bundles.add(Arrays.asList("Beef", "Sprite"));

        for (List<String> bundle : bundles) {
            boolean isBundlePresent = true;

            for (String item : bundle) {
                if (!myItemsList.containsKey(item)) {
                    isBundlePresent = false;
                    break;
                }
            }

            if (isBundlePresent) {
                return true;
            }
        }

    return false;
}



}
