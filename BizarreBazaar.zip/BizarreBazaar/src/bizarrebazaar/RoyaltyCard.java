import java.util.HashMap;
import java.util.Map;

public class RoyaltyCard {

    private String cardNumber;
    private String password;


    public RoyaltyCard() {}
    public RoyaltyCard(String cardNumber, String password) {
        this.cardNumber = cardNumber;
        this.password = password;
    }



    public String getCardNumber() {
        return cardNumber;
    }


    
    public String getPassword() {
        return password;
    }



   public boolean validate() {
        Map<String, String> cardPasswords = getCardPasswords();
        String storedPassword = cardPasswords.get(cardNumber);
        return storedPassword != null && storedPassword.equals(password);
    }



    private Map<String, String> getCardPasswords() {
        Map<String, String> cardPasswords = new HashMap<>();
        cardPasswords.put("1111", "abby");
        cardPasswords.put("2222", "abcd");
        // Add more card numbers and passwords as needed
        return cardPasswords;
    }
    
}
