import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        
        BizarreBazaarGUI bizarreBazaar = new BizarreBazaarGUI();
        bizarreBazaar.setVisible(true);

        // Next button in BizarreBazaar
        bizarreBazaar.getNextButton().addActionListener(e -> {
            if (bizarreBazaar.getMyItemsList().isEmpty()) {
                JOptionPane.showMessageDialog(bizarreBazaar, "Please choose at least one item.");
            } else {
                bizarreBazaar.setVisible(false);
                PaymentGUI payment = new PaymentGUI(bizarreBazaar.getItemsListSum(), bizarreBazaar.getMyItemsList(),
                bizarreBazaar.getMyQuantityList(), false, bizarreBazaar);
            }
        });

        
        // Royalty Card button in BizarreBazaar
        bizarreBazaar.getRoyaltyCardButton().addActionListener(e -> {
            if (bizarreBazaar.getMyItemsList().isEmpty()) {
                JOptionPane.showMessageDialog(bizarreBazaar, "Please choose at least one item.");
                return;
            }

            bizarreBazaar.setVisible(false);
            RoyaltyCardGUI royaltyCardWindow = new RoyaltyCardGUI(bizarreBazaar);
            royaltyCardWindow.setVisible(true);
        });

    }
}
