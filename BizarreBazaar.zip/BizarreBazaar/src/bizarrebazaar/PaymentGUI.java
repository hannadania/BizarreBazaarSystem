import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;
import java.util.Map;

public class PaymentGUI extends JFrame {

    private Map<String, Double> myItemsList;
    private Map<String, Integer> myItemsQuantity;
    private BizarreBazaarGUI bizarreBazaar;
    private PaymentController paymentController;
    private double sumOfTotalPay;
    private JButton payButton;
    private Boolean royalCardBoolean;

    public PaymentGUI(double sumOfTotalPay, Map<String, Double> myItemsList, Map<String, Integer> myItemsQuantity,
    Boolean royalCardBoolean, BizarreBazaarGUI bizarreBazaar) {

        this.sumOfTotalPay = sumOfTotalPay;
        this.myItemsList = myItemsList;
        this.myItemsQuantity = myItemsQuantity;
        this.bizarreBazaar = bizarreBazaar;
        this.royalCardBoolean = royalCardBoolean;
        paymentController = new PaymentController(myItemsList, myItemsQuantity, royalCardBoolean);

        initializeGUI();

        payButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(PaymentGUI.this, "Thanks for paying!");
            bizarreBazaar.deselectCheckboxes();
            bizarreBazaar.clearItemData();

            bizarreBazaar.setVisible(true);
            dispose();
        });

    }

    /////// GUI
    private void initializeGUI() {

 
        JPanel mainPanel = new JPanel(new BorderLayout());

        JPanel headerPanel = bizarreBazaar.createHeaderPanel(mainPanel, "Payment Details", "flower.jpeg");
        headerPanel.setPreferredSize(new Dimension(400, 100));
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        JPanel itemsPanel = new JPanel(new GridLayout(0, 1));
        itemsPanel.setBackground(new Color(250, 232, 235));
        mainPanel.add(itemsPanel);

        displaySelectedItems(itemsPanel);
        


    
        /////// For future bundled discount
        if (paymentController.isBundledDiscountApplicable()) {

            createTotalLabel(itemsPanel, "Total Before Bundled Discount:", Font.BOLD, 30);
            createTotalLabel(itemsPanel, "RM" + getFormattedTotalPrice(sumOfTotalPay), Font.PLAIN, 25);

            createTotalLabel(itemsPanel, "Discount Amount:", Font.BOLD, 30);
            double discountedAmount = paymentController.calculatedDiscountedAmount(sumOfTotalPay, 0.10);
            createTotalLabel(itemsPanel, "RM" + getFormattedTotalPrice(discountedAmount), Font.PLAIN, 25);

            createTotalLabel(itemsPanel, "Total After (Grand Total):", Font.BOLD, 30);
            double discountedTotal = paymentController.calculatedDiscountedTotal(sumOfTotalPay, 0.10);
            createTotalLabel(itemsPanel, "RM" + getFormattedTotalPrice(discountedTotal), Font.PLAIN, 25);
        
        } else {
            if (royalCardBoolean) {
                createTotalLabel(itemsPanel, "Total Before Discount:", Font.BOLD, 30);
                createTotalLabel(itemsPanel, "RM" + getFormattedTotalPrice(sumOfTotalPay), Font.PLAIN, 25);

                createTotalLabel(itemsPanel, "Discount Amount:", Font.BOLD, 30);
                double discountedAmount = paymentController.calculatedDiscountedAmount(sumOfTotalPay, 0.05);
                createTotalLabel(itemsPanel, "RM" + getFormattedTotalPrice(discountedAmount), Font.PLAIN, 25);

                createTotalLabel(itemsPanel, "Total After (Grand Total):", Font.BOLD, 30);
                double discountedTotal = paymentController.calculatedDiscountedTotal(sumOfTotalPay, 0.05);
                createTotalLabel(itemsPanel, "RM" + getFormattedTotalPrice(discountedTotal), Font.PLAIN, 25);
                
            } else {
                createTotalLabel(itemsPanel, "Grand Total:", Font.BOLD, 30);
                createTotalLabel(itemsPanel, "RM" + getFormattedTotalPrice(sumOfTotalPay), Font.PLAIN, 25);
            }
        }

        payButton = new JButton("Pay");
        payButton.setPreferredSize(new Dimension(200, 80));
        payButton.setFont(payButton.getFont().deriveFont(Font.BOLD, 20));
        mainPanel.add(payButton, BorderLayout.SOUTH);


        setTitle("Payment");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 700);
        setLayout(null);
        setContentPane(mainPanel);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    

    private void createTotalLabel (JPanel panel, String text, int style, int size) {
        JLabel label = new JLabel(text);
        label.setFont(label.getFont().deriveFont(style, size));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(label);
    }




    private void displaySelectedItems(JPanel panel) {
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel itemsLabel = new JLabel("Items Purchased:");
        itemsLabel.setFont(itemsLabel.getFont().deriveFont(Font.BOLD, 30));
        panel.add(itemsLabel);

        for (String itemName : myItemsList.keySet()) {
            int quantity = myItemsQuantity.getOrDefault(itemName, 1);
            JLabel itemLabel = new JLabel(quantity + " | " + itemName);
            itemLabel.setFont(itemLabel.getFont().deriveFont(Font.PLAIN, 25));
            itemLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            panel.add(itemLabel);
        }
    }




    public String getFormattedTotalPrice(double price) {
        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        return decimalFormat.format(price);
    }



}
